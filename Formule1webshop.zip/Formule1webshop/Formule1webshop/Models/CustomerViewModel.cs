﻿namespace Formule1webshop.Models
{
    public class CustomerViewModel
    {
    }
}
