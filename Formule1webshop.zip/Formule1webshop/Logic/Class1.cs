﻿namespace Logic
{
    public class Class1
    {

    }
}